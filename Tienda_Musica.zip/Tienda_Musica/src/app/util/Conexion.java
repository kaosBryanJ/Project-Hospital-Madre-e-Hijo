/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author root
 */
public class Conexion {
     public static Connection getConexion(){
        String url="jdbc:mysql://localhost:3306/musica";
        Connection conn = null;
        try{
        
        
        conn = DriverManager.getConnection(url, "root","lpooMy5@l");
    
    }catch(SQLException e){
            System.out.println("Error de conexion" +e);
    }
    return conn;
    
    
    }
    
}
