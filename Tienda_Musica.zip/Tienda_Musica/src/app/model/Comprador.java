/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.model;

/**
 *
 * @author root
 */
public class Comprador extends Persona{
    private String no_comprador;
    private String direccion;
    private String fecha_visita;

    public Comprador(String nombre, String apellido, int edad, String correo, String telefono,String no_comprador, String direccion, String fecha_visita) {
        super(nombre, apellido, edad, correo, telefono);
        this.no_comprador = no_comprador;
        this.direccion = direccion;
        this.fecha_visita = fecha_visita;
    }
    
    

    public String getNo_comprador() {
        return no_comprador;
    }

    public void setNo_comprador(String no_comprador) {
        this.no_comprador = no_comprador;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getFecha_visita() {
        return fecha_visita;
    }

    public void setFecha_visita(String fecha_visita) {
        this.fecha_visita = fecha_visita;
    }
    
    
    
    
}
