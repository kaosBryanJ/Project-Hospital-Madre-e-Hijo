/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.model;

/**
 *
 * @author root
 */
public class Viento extends Instrumento{
    private String material;
    private String envocadura;
    private String sistema_llaves_agujeros;
    private String afinacion;
    private String tubo_conico_cilindrico;

    public Viento(String nombre, double precio, String marca,String material, String envocadura, String sistema_llaves_agujeros, String afinacion, String tubo_conico_cilindrico) {
        super(nombre, precio, marca);
        this.material = material;
        this.envocadura = envocadura;
        this.sistema_llaves_agujeros = sistema_llaves_agujeros;
        this.afinacion = afinacion;
        this.tubo_conico_cilindrico = tubo_conico_cilindrico;
    }
    
    

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getEnvocadura() {
        return envocadura;
    }

    public void setEnvocadura(String envocadura) {
        this.envocadura = envocadura;
    }

    public String getSistema_llaves_agujeros() {
        return sistema_llaves_agujeros;
    }

    public void setSistema_llaves_agujeros(String sistema_llaves_agujeros) {
        this.sistema_llaves_agujeros = sistema_llaves_agujeros;
    }

    public String getAfinacion() {
        return afinacion;
    }

    public void setAfinacion(String afinacion) {
        this.afinacion = afinacion;
    }

    public String getTubo_conico_cilindrico() {
        return tubo_conico_cilindrico;
    }

    public void setTubo_conico_cilindrico(String tubo_conico_cilindrico) {
        this.tubo_conico_cilindrico = tubo_conico_cilindrico;
    }
    
    
    

    
    
}
