/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.model;

/**
 *
 * @author root
 */
public class Cuerda extends Instrumento{
    
    private int num_cuerdas;
    private String estuche;
    private String material;
    private String largo_cuerdas;
    private String accesorios;

    public Cuerda(String nombre, double precio, String marca,int num_cuerdas, String estuche, String material, String largo_cuerdas, String accesorios) {
        super(nombre, precio, marca);
        this.num_cuerdas = num_cuerdas;
        this.estuche = estuche;
        this.material = material;
        this.largo_cuerdas = largo_cuerdas;
        this.accesorios = accesorios;
    }
    
    

    public int getNum_cuerdas() {
        return num_cuerdas;
    }

    public void setNum_cuerdas(int num_cuerdas) {
        this.num_cuerdas = num_cuerdas;
    }

    public String getEstuche() {
        return estuche;
    }

    public void setEstuche(String estuche) {
        this.estuche = estuche;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getLargo_cuerdas() {
        return largo_cuerdas;
    }

    public void setLargo_cuerdas(String largo_cuerdas) {
        this.largo_cuerdas = largo_cuerdas;
    }

    public String getAccesorios() {
        return accesorios;
    }

    public void setAccesorios(String accesorios) {
        this.accesorios = accesorios;
    }
    
    

    
    
}
