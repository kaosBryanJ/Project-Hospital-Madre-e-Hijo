/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.model;

/**
 *
 * @author root
 */
public class Guitarra extends Instrumento{
    private int no_cuerdas;
    private String estampado;
    private String color;
    private String material;
    private String repuestos;

    public Guitarra(String nombre, double precio, String marca,int no_cuerdas, String estampado, String color, String material, String repuestos) {
        super(nombre, precio, marca);
        this.no_cuerdas = no_cuerdas;
        this.estampado = estampado;
        this.color = color;
        this.material = material;
        this.repuestos = repuestos;
    }
    
    

    public int getNo_cuerdas() {
        return no_cuerdas;
    }

    public void setNo_cuerdas(int no_cuerdas) {
        this.no_cuerdas = no_cuerdas;
    }

    public String getEstampado() {
        return estampado;
    }

    public void setEstampado(String estampado) {
        this.estampado = estampado;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getRepuestos() {
        return repuestos;
    }

    public void setRepuestos(String repuestos) {
        this.repuestos = repuestos;
    }
    
    

    
    
}
