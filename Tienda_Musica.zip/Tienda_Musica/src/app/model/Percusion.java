/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.model;

/**
 *
 * @author root
 */
public class Percusion extends Instrumento{
    private String tipo;
    private String material;
    private String diseno;
    private String tono_timbre;
    private String sistema_afinacion;

    public Percusion(String nombre, double precio, String marca,String tipo, String material, String diseno, String tono_timbre, String sistema_afinacion) {
        super(nombre, precio, marca);
        this.tipo = tipo;
        this.material = material;
        this.diseno = diseno;
        this.tono_timbre = tono_timbre;
        this.sistema_afinacion = sistema_afinacion;
    }
    
    

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getDiseno() {
        return diseno;
    }

    public void setDiseno(String diseno) {
        this.diseno = diseno;
    }

    public String getTono_timbre() {
        return tono_timbre;
    }

    public void setTono_timbre(String tono_timbre) {
        this.tono_timbre = tono_timbre;
    }

    public String getSistema_afinacion() {
        return sistema_afinacion;
    }

    public void setSistema_afinacion(String sistema_afinacion) {
        this.sistema_afinacion = sistema_afinacion;
    }
    
    

    
    
    
    
}
