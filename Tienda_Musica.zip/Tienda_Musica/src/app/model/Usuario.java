/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.model;

/**
 *
 * @author root
 */
public class Usuario extends Persona{
    
    private String login;
    private String password;

    public Usuario(String login, String password, String nombre, String apellido, int edad, String correo, String telefono) {
        super(nombre, apellido, edad, correo, telefono);
        this.login = login;
        this.password = password;
    }

    

    

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
    
}
