/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.model;

/**
 *
 * @author root
 */
public class Audio extends Instrumento{
    private int potencia;
    private String tipo_altavoz;
    private String accesorios;
    private String aplificadores;
    private double frecuencia;

    public Audio(String nombre, double precio, String marca, int potencia, String tipo_altavoz, String accesorios, String aplificadores, double frecuencia) {
        super(nombre, precio, marca);
        this.potencia = potencia;
        this.tipo_altavoz = tipo_altavoz;
        this.accesorios = accesorios;
        this.aplificadores = aplificadores;
        this.frecuencia = frecuencia;
    }
    
    

    public int getPotencia() {
        return potencia;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }

    public String getTipo_altavoz() {
        return tipo_altavoz;
    }

    public void setTipo_altavoz(String tipo_altavoz) {
        this.tipo_altavoz = tipo_altavoz;
    }

    public String getAccesorios() {
        return accesorios;
    }

    public void setAccesorios(String accesorios) {
        this.accesorios = accesorios;
    }

    public String getAplificadores() {
        return aplificadores;
    }

    public void setAplificadores(String aplificadores) {
        this.aplificadores = aplificadores;
    }

    public double getFrecuencia() {
        return frecuencia;
    }

    public void setFrecuencia(double frecuencia) {
        this.frecuencia = frecuencia;
    }
    
    

    
}
