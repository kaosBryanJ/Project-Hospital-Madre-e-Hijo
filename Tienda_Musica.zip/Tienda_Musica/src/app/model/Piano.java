/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.model;

/**
 *
 * @author root
 */
public class Piano extends Instrumento{
    
    private int no_teclas;
    private String tamano;
    private String eculizador;
    private String partituras;
    private String cables;

    public Piano( String nombre, double precio, String marca,int no_teclas, String tamano, String eculizador, String partituras, String cables) {
        super(nombre, precio, marca);
        this.no_teclas = no_teclas;
        this.tamano = tamano;
        this.eculizador = eculizador;
        this.partituras = partituras;
        this.cables = cables;
    }
    
    

    public int getNo_teclas() {
        return no_teclas;
    }

    public void setNo_teclas(int no_teclas) {
        this.no_teclas = no_teclas;
    }

    public String getTamano() {
        return tamano;
    }

    public void setTamano(String tamano) {
        this.tamano = tamano;
    }

    public String getEculizador() {
        return eculizador;
    }

    public void setEculizador(String eculizador) {
        this.eculizador = eculizador;
    }

    public String getPartituras() {
        return partituras;
    }

    public void setPartituras(String partituras) {
        this.partituras = partituras;
    }

    public String getCables() {
        return cables;
    }

    public void setCables(String cables) {
        this.cables = cables;
    }
    
    

    
    
    
}
