/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.model;

/**
 *
 * @author root
 */
public class Empleado extends Persona{
    private int no_empleado;
    private String area;
    private String horario;

    public Empleado( String nombre, String apellido, int edad, String correo, String telefono,int no_empleado, String area, String horario) {
        super(nombre, apellido, edad, correo, telefono);
        this.no_empleado = no_empleado;
        this.area = area;
        this.horario = horario;
    }
    
    

    public int getNo_empleado() {
        return no_empleado;
    }

    public void setNo_empleado(int no_empleado) {
        this.no_empleado = no_empleado;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }
    
    

   
    
}
