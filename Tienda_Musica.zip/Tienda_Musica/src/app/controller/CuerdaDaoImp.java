/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.controller;

import app.model.Cuerda;
import app.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author root
 */
public class CuerdaDaoImp implements CuerdaDao{

    @Override
    public void guardarCuerda(Cuerda cuerda) {
           try {
            Connection conn = Conexion.getConexion();
            String query = "INSERT INTO instrumentos(nombre, precio, marca) VALUES (?,?,?)";
            PreparedStatement ps = conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, cuerda.getNombre());
            ps.setDouble(2, cuerda.getPrecio());
            ps.setString(3, cuerda.getMarca());
            
            ps.executeUpdate();
            
            ResultSet generatedKeys = ps.getGeneratedKeys();
            int instrumento_id= 0;
            
            if (generatedKeys.next()) {
                instrumento_id = generatedKeys.getInt(1);
                
                query = "INSERT INTO cuerda(num_cuerdas,estuche,material,largo,accesorios, instrumento_id) VALUES (?,?,?,?,?,?)";
                ps = conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
                ps.setInt(1,cuerda.getNum_cuerdas());
                ps.setString(2, cuerda.getEstuche());
                ps.setString(3, cuerda.getMaterial());
                ps.setString(4, cuerda.getLargo_cuerdas());
                ps.setString(5,cuerda.getAccesorios());
                ps.setInt(6,instrumento_id);
                
                ps.executeUpdate();
                
                JOptionPane.showMessageDialog(null, "El Instrumento de CUERDA se guardo exitosamente");
               
                
            }else{
                JOptionPane.showMessageDialog(null, "El Instrumento de CUERDA no se guardo exitosamente");
                
            }
        } catch (Exception e) {
             System.out.println("Error de la conexion "+e);
        }
    }

    @Override
    public void modificarCuerda(Cuerda cuerda, int id) {
        try {
            Connection conn = Conexion.getConexion();
            //recuperar ID de instrumento
            String query = "SELECT instrumento_id,id from cuerda where id = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            int instrumento_id = 0;
            
            while(rs.next()){
                instrumento_id = rs.getInt("instrumento_id");
                
            }
            
            query = ("UPDATE instrumentos set nombre=?,precio=?, marca=? WHERE id = ?");
            ps = conn.prepareStatement(query);
            ps.setString(1, cuerda.getNombre());
            ps.setDouble(2, cuerda.getPrecio());
            ps.setString(3, cuerda.getMarca());
            ps.setInt(4,instrumento_id);
            
            ps.executeUpdate();
            
            query = ("update cuerda set num_cuerdas = ?,estuche=?,material=?,largo=?,accesorios=?  where id = ?");
            ps = conn.prepareStatement(query);
            ps.setInt(1,cuerda.getNum_cuerdas());
            ps.setString(2, cuerda.getEstuche());
                ps.setString(3, cuerda.getMaterial());
                ps.setString(4, cuerda.getLargo_cuerdas());
                ps.setString(5,cuerda.getAccesorios());
            ps.setInt(6,id);
            
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "El instrumento deCUERDA se modifico");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "El instrumento de CUERDAS no se modifico "+e);
            
        }
    }

    @Override
    public void eliminarCuerda(int id) {
        try {
            Connection conn = Conexion.getConexion();
            
            String query = "SELECT instrumento_id, id from cuerda where id = ?";
             PreparedStatement ps = conn.prepareStatement(query);
             ps.setInt(1,id);
             ResultSet rs = ps.executeQuery();
             int instrumento_id = 0;
             
             while(rs.next()){
                 instrumento_id = rs.getInt("instrumento_id");
                 
             }
             
             //eleiminar el audio
             query = "DELETE FROM cuerda where id = ?";
             ps = conn.prepareStatement(query);
             ps.setInt(1, id);
             
             ps.executeUpdate();
             
             //eliminar instrumento
             query = "DELETE FROM instrumentos WHERE id =?";
             ps = conn.prepareStatement(query);
             ps.setInt(1,instrumento_id);
             
             ps.executeUpdate();
             
             
            JOptionPane.showMessageDialog(null, "El instrumento de Cuerda se elimino");
            
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "El instrumento de cuerda no se elimino "+e);
            
        }
    }

    @Override
    public void construirTabla(DefaultTableModel modeloTabla) {
         try {
            Connection conn = Conexion.getConexion();
            String query = "SELECT cu.id, nombre,precio,marca,num_cuerdas,estuche,material,largo,accesorios from instrumentos i, cuerda cu WHERE i.id=cu.instrumento_id";
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery();
             ResultSetMetaData rsmd = rs.getMetaData();
             int columnas= rsmd.getColumnCount();
             while(rs.next()){
                 Object[] fila=new Object[columnas];
                 for(int indice = 0; indice < columnas; indice++){
                     fila[indice] = rs.getObject(indice+1);
                 }
                 modeloTabla.addRow(fila);
             }
             
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al contruir tabla "+e);
        }
    }

    @Override
    public Cuerda consultarCuerda(int id) {
        Cuerda cuerda = null;
        try {
           Connection conn = Conexion.getConexion();
           String query = "SELECT cu.id, nombre,precio,marca,num_cuerdas,estuche,material,largo,accesorios FROM instrumentos i, cuerda cu WHERE i.id=cu.instrumento_id and cu.id=?";
           PreparedStatement ps = conn.prepareStatement(query);
             ps.setInt(1,id);
             ResultSet rs = ps.executeQuery();
             
             while(rs.next()){
                 cuerda = new Cuerda(rs.getString("nombre"),
                         rs.getDouble("precio"),
                         rs.getString("marca"),
                         rs.getInt("num_cuerdas"),
                         rs.getString("estuche"),
                         rs.getString("material"),
                          rs.getString("largo"),
                          rs.getString("accesorios"));
             }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar CUERDA "+e);
        }
        return cuerda;
    }

    public void contruirTabla(DefaultTableModel modeloTabla) {
        try {
            Connection conn = Conexion.getConexion();
            String query = "SELECT cu.id, nombre,precio,marca,num_cuerdas,estuche,material,largo,accesorios  from instrumentos i, cuerda cu WHERE i.id=cu.instrumento_id";
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery();
             ResultSetMetaData rsmd = rs.getMetaData();
             int columnas= rsmd.getColumnCount();
             while(rs.next()){
                 Object[] fila=new Object[columnas];
                 for(int indice = 0; indice < columnas; indice++){
                     fila[indice] = rs.getObject(indice+1);
                 }
                 modeloTabla.addRow(fila);
             }
             
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al contruir tabla "+e);
        }
    }
    
}
