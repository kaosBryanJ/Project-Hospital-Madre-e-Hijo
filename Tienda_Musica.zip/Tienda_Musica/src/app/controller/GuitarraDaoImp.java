/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.controller;

import app.model.Guitarra;
import app.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author root
 */
public class GuitarraDaoImp implements GuitarraDao{

    @Override
    public void guardarGuitarra(Guitarra guitarra) {
        try {
            Connection conn = Conexion.getConexion();
            String query = "INSERT INTO instrumentos(nombre, precio, marca) VALUES (?,?,?)";
            PreparedStatement ps = conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, guitarra.getNombre());
            ps.setDouble(2, guitarra.getPrecio());
            ps.setString(3, guitarra.getMarca());
            
            ps.executeUpdate();
            
            ResultSet generatedKeys = ps.getGeneratedKeys();
            int instrumento_id= 0;
            
            if (generatedKeys.next()) {
                instrumento_id = generatedKeys.getInt(1);
                
                query = "INSERT INTO guitarra(no_cuerdas,estampado,color,material,repuestos, instrumento_id) VALUES (?,?,?,?,?,?)";
                ps = conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
                ps.setInt(1,guitarra.getNo_cuerdas());
                ps.setString(2, guitarra.getEstampado());
                ps.setString(3, guitarra.getColor());
                ps.setString(4,guitarra.getMaterial());
                ps.setString(5,guitarra.getRepuestos());
                ps.setInt(6,instrumento_id);
                
                ps.executeUpdate();
                
                JOptionPane.showMessageDialog(null, "La Guitarra se guardo exitosamente");
               
                
            }else{
                JOptionPane.showMessageDialog(null, "La Guitarra no se guardo exitosamente");
                
            }
        } catch (Exception e) {
             System.out.println("Error de la conexion "+e);
        }
    }

    @Override
    public void modificarGuitarra(Guitarra guitarra, int id) {
       try {
            Connection conn = Conexion.getConexion();
            //recuperar ID de instrumento
            String query = "SELECT instrumento_id,id from guitarra where id = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            int instrumento_id = 0;
            
            while(rs.next()){
                instrumento_id = rs.getInt("instrumento_id");
                
            }
            
            query = ("UPDATE instrumentos set nombre=?,precio=?, marca=? WHERE id = ?");
            ps = conn.prepareStatement(query);
            ps.setString(1, guitarra.getNombre());
            ps.setDouble(2, guitarra.getPrecio());
            ps.setString(3, guitarra.getMarca());
            ps.setInt(4,instrumento_id);
            
            ps.executeUpdate();
            
            query = ("update guitarra set no_cuerdas = ?,estampado=?,color=?,material=?,repuestos=? where id = ?");
            ps = conn.prepareStatement(query);
            ps.setInt(1,guitarra.getNo_cuerdas());
            ps.setString(2, guitarra.getEstampado());
                ps.setString(3, guitarra.getColor());
                ps.setString(4,guitarra.getMaterial());
                ps.setString(5,guitarra.getRepuestos());
            ps.setInt(6,id);
            
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "La Guitarra se modifico");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "La Guitarra no se modifico "+e);
            
        } 
    }

    @Override
    public void eliminarGuitarra(int id) {
        try {
            Connection conn = Conexion.getConexion();
            
            String query = "SELECT instrumento_id, id from guitarra where id = ?";
             PreparedStatement ps = conn.prepareStatement(query);
             ps.setInt(1,id);
             ResultSet rs = ps.executeQuery();
             int instrumento_id = 0;
             
             while(rs.next()){
                 instrumento_id = rs.getInt("instrumento_id");
                 
             }
             
             //eleiminar el audio
             query = "DELETE FROM guitarra where id = ?";
             ps = conn.prepareStatement(query);
             ps.setInt(1, id);
             
             ps.executeUpdate();
             
             //eliminar instrumento
             query = "DELETE FROM instrumentos WHERE id =?";
             ps = conn.prepareStatement(query);
             ps.setInt(1,instrumento_id);
             
             ps.executeUpdate();
             
             
            JOptionPane.showMessageDialog(null, " La Guitarra se elimino");
            
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "La Guitarra no se elimino "+e);
            
        }
    }

    @Override
    public void construirTabla(DefaultTableModel modeloTabla) {
        try {
            Connection conn = Conexion.getConexion();
            String query = "SELECT g.id, nombre,precio,marca,no_cuerdas,estampado,color,material,repuestos from instrumentos i, guitarra g WHERE i.id=g.instrumento_id";
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery();
             ResultSetMetaData rsmd = rs.getMetaData();
             int columnas= rsmd.getColumnCount();
             while(rs.next()){
                 Object[] fila=new Object[columnas];
                 for(int indice = 0; indice < columnas; indice++){
                     fila[indice] = rs.getObject(indice+1);
                 }
                 modeloTabla.addRow(fila);
             }
             
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al contruir tabla "+e);
        }
    }

    @Override
    public Guitarra consultarGuitarra(int id) {
        Guitarra guitarra= null;
        try {
           Connection conn = Conexion.getConexion();
           String query = "SELECT g.id, nombre,precio,marca,no_cuerdas,estampado,color,material,repuestos FROM instrumentos i, guitarra g WHERE i.id=g.instrumento_id and g.id=?";
           PreparedStatement ps = conn.prepareStatement(query);
             ps.setInt(1,id);
             ResultSet rs = ps.executeQuery();
             
             while(rs.next()){
                 guitarra= new Guitarra(rs.getString("nombre"),
                         rs.getDouble("precio"),
                         rs.getString("marca"),
                         rs.getInt("no_cuerdas"),
                         rs.getString("estampado"),
                         rs.getString("color"),
                         rs.getString("material"),
                           rs.getString("repuestos"));
             }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar GUITARRA "+e);
        }
        return guitarra;
    }

    public void contruirTabla(DefaultTableModel modeloTabla) {
        try {
            Connection conn = Conexion.getConexion();
            String query = "SELECT g.id, nombre,precio,marca,no_cuerdas,estampado,color,material,repuestos from instrumentos i, guitarra g WHERE i.id=g.instrumento_id";
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery();
             ResultSetMetaData rsmd = rs.getMetaData();
             int columnas= rsmd.getColumnCount();
             while(rs.next()){
                 Object[] fila=new Object[columnas];
                 for(int indice = 0; indice < columnas; indice++){
                     fila[indice] = rs.getObject(indice+1);
                 }
                 modeloTabla.addRow(fila);
             }
             
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al contruir tabla "+e);
        }
    }
    
    
}
