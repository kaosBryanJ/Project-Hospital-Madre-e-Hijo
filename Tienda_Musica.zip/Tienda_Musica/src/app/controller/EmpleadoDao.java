/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package app.controller;


import app.model.Empleado;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author root
 */
public interface EmpleadoDao {
    
    public abstract void guardarEmpleado(Empleado empleado);
    
    public abstract void modificarEmpleado(Empleado empleado, int id);
    
    public abstract void eliminarEmpleado(int id);
    
    public abstract void construirTabla(DefaultTableModel modeloTabla);
    
    public abstract Empleado consultarEmpleado(int id);
    
}
