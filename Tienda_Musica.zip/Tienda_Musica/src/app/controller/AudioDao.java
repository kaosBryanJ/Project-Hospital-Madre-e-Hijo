/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package app.controller;


import app.model.Audio;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author root
 */
public interface AudioDao {
    
    
    public abstract void guardarAudio(Audio audio);
    
    public abstract void modificarAudio(Audio audio, int id);
    
    public abstract void eliminarAudio(int id);
    
    public abstract void construirTabla(DefaultTableModel modeloTabla);
    
    public abstract Audio consultarAudio(int id);
    
}
