/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.controller;

import app.model.Audio;
import app.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author root
 */
public class AudioDaoImp implements AudioDao{

    @Override
    public void guardarAudio(Audio audio) {
          try {
            Connection conn = Conexion.getConexion();
            String query = "INSERT INTO instrumentos(nombre, precio, marca) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, audio.getNombre());
            ps.setDouble(2, audio.getPrecio());
            ps.setString(3, audio.getMarca());
            
            ps.executeUpdate();
            
            ResultSet generatedKeys = ps.getGeneratedKeys();
            int instrumento_id= 0;
            
            if (generatedKeys.next()) {
                instrumento_id = generatedKeys.getInt(1);
                
                query = "INSERT INTO audio(potencia,tipo_altavoz,accesorios,amplificador,frecuencia, instrumento_id) VALUES (?,?,?,?,?,?)";
                ps = conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
                ps.setInt(1,audio.getPotencia());
                ps.setString(2,audio.getTipo_altavoz());
                ps.setString(3, audio.getAccesorios());
                ps.setString(4, audio.getAplificadores());
                ps.setDouble(5,audio.getFrecuencia());
                ps.setInt(6,instrumento_id);
                
                ps.executeUpdate();
                
                JOptionPane.showMessageDialog(null, "El Instrumento de AUDIO se guardo exitosamente");
               
                
            }else{
                JOptionPane.showMessageDialog(null, "El Instrumento de AUDIO no se guardo exitosamente");
                
            }
        } catch (Exception e) {
             System.out.println("Error de la conexion "+e);
        }
    }

    @Override
    public void modificarAudio(Audio audio, int id) {
        try {
            Connection conn = Conexion.getConexion();
            //recuperar ID de instrumento
            String query = "SELECT instrumento_id,id from audio where id = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            int instrumento_id = 0;
            
            while(rs.next()){
                instrumento_id = rs.getInt("instrumento_id");
                
            }
            
            query = ("UPDATE instrumentos set nombre=?,precio=?, marca=? WHERE id = ?");
            ps = conn.prepareStatement(query);
            ps.setString(1, audio.getNombre());
            ps.setDouble(2, audio.getPrecio());
            ps.setString(3, audio.getMarca());
            ps.setInt(4,instrumento_id);
            
            ps.executeUpdate();
            
            query = ("update audio set potencia = ?,tipo_altavoz = ?,accesorios=?,amplificador=?,frecuencia=?  where id = ?");
            ps = conn.prepareStatement(query);
            ps.setInt(1,audio.getPotencia());
            ps.setString(2,audio.getTipo_altavoz());
           
                ps.setString(3, audio.getAccesorios());
                ps.setString(4, audio.getAplificadores());
                ps.setDouble(5,audio.getFrecuencia());
            ps.setInt(6,id);
            
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "El instrumento de AUDIO se modifico");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "El instrumento de AUDIO no se modifico "+e);
            
        }
    }

    @Override
    public void eliminarAudio(int id) {
        try {
            Connection conn = Conexion.getConexion();
            
            String query = "SELECT instrumento_id, id from audio where id = ?";
             PreparedStatement ps = conn.prepareStatement(query);
             ps.setInt(1,id);
             ResultSet rs = ps.executeQuery();
             int instrumento_id = 0;
             
             while(rs.next()){
                 instrumento_id = rs.getInt("instrumento_id");
                 
             }
             
             //eleiminar el audio
             query = "DELETE FROM audio where id = ?";
             ps = conn.prepareStatement(query);
             ps.setInt(1, id);
             
             ps.executeUpdate();
             
             //eliminar instrumento
             query = "DELETE FROM instrumentos WHERE id =?";
             ps = conn.prepareStatement(query);
             ps.setInt(1,instrumento_id);
             
             ps.executeUpdate();
             
             
            JOptionPane.showMessageDialog(null, "El AUDIO se elimino");
            
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "El AUDIO no se elimino "+e);
            
        }
    }

    @Override
    public void construirTabla(DefaultTableModel modeloTabla) {
        try {
            Connection conn = Conexion.getConexion();
            String query = "SELECT au.id, nombre,precio,marca,potencia,tipo_altavoz,accesorios,amplificador,frecuencia from instrumentos i, audio au WHERE i.id=au.instrumento_id";
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery();
             ResultSetMetaData rsmd = rs.getMetaData();
             int columnas= rsmd.getColumnCount();
             while(rs.next()){
                 Object[] fila=new Object[columnas];
                 for(int indice = 0; indice < columnas; indice++){
                     fila[indice] = rs.getObject(indice+1);
                 }
                 modeloTabla.addRow(fila);
             }
             
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al contruir tabla "+e);
        }
    }

    @Override
    public Audio consultarAudio(int id) {
        Audio audio = null;
        try {
           Connection conn = Conexion.getConexion();
           String query = "SELECT au.id, nombre,precio,marca,potencia, tipo_altavoz,accesorios,amplificador,frecuencia FROM instrumentos i, audio au WHERE i.id=au.instrumento_id and au.id=?";
           PreparedStatement ps = conn.prepareStatement(query);
             ps.setInt(1,id);
             ResultSet rs = ps.executeQuery();
             
             while(rs.next()){
                 audio = new Audio(rs.getString("nombre"),
                         rs.getDouble("precio"),
                         rs.getString("marca"),
                         rs.getInt("potencia"),
                         rs.getString("tipo_altavoz"),
                        rs.getString("accesorios"),
                        rs.getString("amplificador"),
                         rs.getDouble("frecuencia"));
             }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar PIANO "+e);
        }
        return audio;
    }

    public void contruirTabla(DefaultTableModel modeloTabla) {
        try {
            Connection conn = Conexion.getConexion();
            String query = "SELECT au.id, nombre,precio,marca,potencia,tipo_altavoz,accesorios,amplificador,frecuencia from instrumentos i, audio au WHERE i.id=au.instrumento_id";
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery();
             ResultSetMetaData rsmd = rs.getMetaData();
             int columnas= rsmd.getColumnCount();
             while(rs.next()){
                 Object[] fila=new Object[columnas];
                 for(int indice = 0; indice < columnas; indice++){
                     fila[indice] = rs.getObject(indice+1);
                 }
                 modeloTabla.addRow(fila);
             }
             
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al contruir tabla "+e);
        }
        
    }
    
}
