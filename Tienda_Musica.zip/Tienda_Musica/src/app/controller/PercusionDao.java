/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package app.controller;


import app.model.Percusion;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author root
 */
public interface PercusionDao {
     public abstract void guardarPercusion(Percusion percusion);
    
    public abstract void modificarPercusion(Percusion percusion, int id);
    
    public abstract void eliminarPercusion(int id);
    
    public abstract void construirTabla(DefaultTableModel modeloTabla);
    
    public abstract Percusion consultarPercusion(int id);
    
}
