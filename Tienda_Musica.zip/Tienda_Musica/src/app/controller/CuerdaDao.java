/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package app.controller;


import app.model.Cuerda;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author root
 */
public interface CuerdaDao {
    
    public abstract void guardarCuerda(Cuerda cuerda);
    
    public abstract void modificarCuerda(Cuerda cuerda, int id);
    
    public abstract void eliminarCuerda(int id);
    
    public abstract void construirTabla(DefaultTableModel modeloTabla);
    
    public abstract Cuerda consultarCuerda(int id);
    
}
