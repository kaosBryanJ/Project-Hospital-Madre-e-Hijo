/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.controller;

import app.model.Empleado;
import app.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author root
 */
public class EmpleadoDaoImp implements EmpleadoDao{

    @Override
    public void guardarEmpleado(Empleado empleado) {
        try {
            Connection conn = Conexion.getConexion();
            String query = "INSERT INTO personas(nombre, apellido,edad,correo,telefono) VALUES (?,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, empleado.getNombre());
            ps.setString(2, empleado.getApellido());
            ps.setInt(3, empleado.getEdad());
            ps.setString(4, empleado.getCorreo());
            ps.setString(5,empleado.getTelefono());
            
            ps.executeUpdate();
            
            ResultSet generatedKeys = ps.getGeneratedKeys();
            int persona_id= 0;
            
            if (generatedKeys.next()) {
                persona_id = generatedKeys.getInt(1);
                
                query = "INSERT INTO empleado(no_empleado,area,horario, persona_id) VALUES (?,?,?,?)";
                ps = conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
                ps.setInt(1,empleado.getNo_empleado());
                ps.setString(2,empleado.getArea());
                ps.setString(3,empleado.getHorario());
                
                ps.setInt(4,persona_id);
                
                ps.executeUpdate();
                
                JOptionPane.showMessageDialog(null, "El Empleado se guardo exitosamente");
               
                
            }else{
                JOptionPane.showMessageDialog(null, "El Empleado no se guardo exitosamente");
                
            }
        } catch (Exception e) {
             System.out.println("Error de la conexion "+e);
        }
    }

    @Override
    public void modificarEmpleado(Empleado empleado, int id) {
        try {
            Connection conn = Conexion.getConexion();
            //recuperar ID de instrumento
            String query = "SELECT persona_id,id from empleado where id = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            int persona_id = 0;
            
            while(rs.next()){
                persona_id = rs.getInt("persona_id");
                
            }
            
            query = ("UPDATE personas set nombre=?,apellido=?, edad=?,correo=?, telefono=? WHERE id = ?");
            ps = conn.prepareStatement(query);
            ps.setString(1, empleado.getNombre());
            ps.setString(2, empleado.getApellido());
            ps.setInt(3,empleado.getEdad());
            ps.setString(4, empleado.getCorreo());
            ps.setString(5, empleado.getTelefono());
            ps.setInt(6,persona_id);
            
            ps.executeUpdate();
            
            query = ("update empleado set no_empleado=?,area=?,horario=? where id = ?");
            ps = conn.prepareStatement(query);
            ps.setInt(1,empleado.getNo_empleado());
            ps.setString(2,empleado.getArea());
                ps.setString(3,empleado.getHorario());
            
            ps.setInt(4,id);
            
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Empleado modificado");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Empleado no modificado "+e);
            
        }
    }

    @Override
    public void eliminarEmpleado(int id) {
        try {
            Connection conn = Conexion.getConexion();
            
            String query = "SELECT persona_id, id from empleado where id = ?";
             PreparedStatement ps = conn.prepareStatement(query);
             ps.setInt(1,id);
             ResultSet rs = ps.executeQuery();
             int persona_id = 0;
             
             while(rs.next()){
                 persona_id = rs.getInt("persona_id");
                 
             }
             
             //eleiminar el audio
             query = "DELETE FROM empleado where id = ?";
             ps = conn.prepareStatement(query);
             ps.setInt(1, id);
             
             ps.executeUpdate();
             
             //eliminar instrumento
             query = "DELETE FROM personas WHERE id =?";
             ps = conn.prepareStatement(query);
             ps.setInt(1,persona_id);
             
             ps.executeUpdate();
             
             
            JOptionPane.showMessageDialog(null, "El empleado se elimino");
            
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "El empleado no se elimino "+e);
            
        }
    }

    @Override
    public void construirTabla(DefaultTableModel modeloTabla) {
        try {
            Connection conn = Conexion.getConexion();
            String query = "SELECT emp.id, nombre,apellido,edad,correo,telefono,no_empleado from personas p, empleado emp WHERE p.id=emp.persona_id";
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery();
             ResultSetMetaData rsmd = rs.getMetaData();
             int columnas= rsmd.getColumnCount();
             while(rs.next()){
                 Object[] fila=new Object[columnas];
                 for(int indice = 0; indice < columnas; indice++){
                     fila[indice] = rs.getObject(indice+1);
                 }
                 modeloTabla.addRow(fila);
             }
             
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al contruir tabla "+e);
        }
    }

    @Override
    public Empleado consultarEmpleado(int id) {
        Empleado empleado = null;
        try {
           Connection conn = Conexion.getConexion();
           String query = "SELECT emp.id, nombre,apellido,edad,correo,telefono,no_empleado,area,horario FROM personas p, empleado emp WHERE p.id=emp.persona_id and emp.id=?";
           PreparedStatement ps = conn.prepareStatement(query);
             ps.setInt(1,id);
             ResultSet rs = ps.executeQuery();
             
             while(rs.next()){
                 empleado = new Empleado(rs.getString("nombre"),
                         rs.getString("apellido"),
                         rs.getInt("edad"),
                         rs.getString("correo"),

                         rs.getString("telefono"),
                         rs.getInt("no_empleado"),
                           rs.getString("area"),
                             rs.getString("horario"));
             }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar empleado "+e);
        }
        return empleado;
    }

    public void contruirTabla(DefaultTableModel modeloTabla) {
        try {
            Connection conn = Conexion.getConexion();
            String query = "SELECT emp.id, nombre,apellido,correo,telefono,no_empleado,area,horario from personas p, empleado emp WHERE p.id=emp.persona_id";
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery();
             ResultSetMetaData rsmd = rs.getMetaData();
             int columnas= rsmd.getColumnCount();
             while(rs.next()){
                 Object[] fila=new Object[columnas];
                 for(int indice = 0; indice < columnas; indice++){
                     fila[indice] = rs.getObject(indice+1);
                 }
                 modeloTabla.addRow(fila);
             }
             
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al contruir tabla "+e);
        }
    }
    
}
