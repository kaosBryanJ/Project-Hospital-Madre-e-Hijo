/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package app.controller;


import app.model.Comprador;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author root
 */
public interface CompradorDao {
    
     public abstract void guardarComprador(Comprador comprador);
    
    public abstract void modificarComprador(Comprador comprador, int id);
    
    public abstract void eliminarComprador(int id);
    
    public abstract void construirTabla(DefaultTableModel modeloTabla);
    
    public abstract Comprador consultarComprador(int id);
    
}
