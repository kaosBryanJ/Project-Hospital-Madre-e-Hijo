/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package app.controller;


import app.model.Guitarra;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author root
 */
public interface GuitarraDao {
    
    public abstract void guardarGuitarra(Guitarra guitarra);
    
    public abstract void modificarGuitarra(Guitarra guitarra, int id);
    
    public abstract void eliminarGuitarra(int id);
    
    public abstract void construirTabla(DefaultTableModel modeloTabla);
    
    public abstract Guitarra consultarGuitarra(int id);
    
}
