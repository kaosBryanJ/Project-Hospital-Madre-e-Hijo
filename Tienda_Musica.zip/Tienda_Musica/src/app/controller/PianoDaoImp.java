/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.controller;

import app.model.Piano;
import app.util.Conexion;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author root
 */
public class PianoDaoImp implements PianoDao{

    @Override
    public void guardarPiano(Piano piano) {
        try {
            Connection conn = Conexion.getConexion();
            String query = "INSERT INTO instrumentos(nombre, precio, marca) VALUES (?,?,?)";
            PreparedStatement ps = conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, piano.getNombre());
            ps.setDouble(2, piano.getPrecio());
            ps.setString(3, piano.getMarca());
            
            ps.executeUpdate();
            
            ResultSet generatedKeys = ps.getGeneratedKeys();
            int instrumento_id= 0;
            
            if (generatedKeys.next()) {
                instrumento_id = generatedKeys.getInt(1);
                
                query = "INSERT INTO piano(no_teclas,tamano,ecualizador,partituras,cables, instrumento_id) VALUES (?,?,?,?,?,?)";
                ps = conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
                ps.setInt(1,piano.getNo_teclas());
                ps.setString(2,piano.getTamano());
                ps.setString(3, piano.getEculizador());
                ps.setString(4, piano.getPartituras());
                ps.setString(5, piano.getCables());
                ps.setInt(6,instrumento_id);
                
                ps.executeUpdate();
                
                JOptionPane.showMessageDialog(null, "El Piano se guardo exitosamente");
               
                
            }else{
                JOptionPane.showMessageDialog(null, "El Piano no se guardo exitosamente");
                
            }
        } catch (Exception e) {
             System.out.println("Error de la conexion "+e);
        }
    }

    @Override
    public void modificarPiano(Piano piano, int id) {
        try {
            Connection conn = Conexion.getConexion();
            //recuperar ID de instrumento
            String query = "SELECT instrumento_id,id from piano where id = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            int instrumento_id = 0;
            
            while(rs.next()){
                instrumento_id = rs.getInt("instrumento_id");
                
            }
            
            query = ("UPDATE instrumentos set nombre=?,precio=?, marca=? WHERE id = ?");
            ps = conn.prepareStatement(query);
            ps.setString(1, piano.getNombre());
            ps.setDouble(2, piano.getPrecio());
            ps.setString(3, piano.getMarca());
            ps.setInt(4,instrumento_id);
            
            ps.executeUpdate();
            
            query = ("update piano set no_teclas = ?,tamano=?,ecualizador=?,partituras=?,cables=? where id = ?");
            ps = conn.prepareStatement(query);
            ps.setInt(1,piano.getNo_teclas());
            ps.setString(2,piano.getTamano());
                ps.setString(3, piano.getEculizador());
                ps.setString(4, piano.getPartituras());
                ps.setString(5, piano.getCables());
            ps.setInt(6,id);
            
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "PIANO se modifico");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "PIANO no se modifico "+e);
            
        }
        
    }

    @Override
    public void eliminarPiano(int id) {
        try {
            Connection conn = Conexion.getConexion();
            
            String query = "SELECT instrumento_id, id from piano where id = ?";
             PreparedStatement ps = conn.prepareStatement(query);
             ps.setInt(1,id);
             ResultSet rs = ps.executeQuery();
             int instrumento_id = 0;
             
             while(rs.next()){
                 instrumento_id = rs.getInt("instrumento_id");
                 
             }
             
             //eleiminar el audio
             query = "DELETE FROM piano where id = ?";
             ps = conn.prepareStatement(query);
             ps.setInt(1, id);
             
             ps.executeUpdate();
             
             //eliminar instrumento
             query = "DELETE FROM instrumentos WHERE id =?";
             ps = conn.prepareStatement(query);
             ps.setInt(1,instrumento_id);
             
             ps.executeUpdate();
             
             
            JOptionPane.showMessageDialog(null, "El PIANO se elimino");
            
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "El PIANO no se elimino "+e);
            
        }
    }

    @Override
    public void construirTabla(DefaultTableModel modeloTabla) {
        try {
            Connection conn = Conexion.getConexion();
            String query = "SELECT pi.id, nombre,precio,marca,no_teclas,tamano,ecualizador,partituras,cables from instrumentos i, piano pi WHERE i.id=pi.instrumento_id";
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery();
             ResultSetMetaData rsmd = rs.getMetaData();
             int columnas= rsmd.getColumnCount();
             while(rs.next()){
                 Object[] fila=new Object[columnas];
                 for(int indice = 0; indice < columnas; indice++){
                     fila[indice] = rs.getObject(indice+1);
                 }
                 modeloTabla.addRow(fila);
             }
             
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al contruir tabla "+e);
        }
    }

    @Override
    public Piano consultarPiano(int id) {
        Piano piano= null;
        try {
           Connection conn = Conexion.getConexion();
           String query = "SELECT pi.id, nombre,precio,marca,no_teclas,tamano,ecualizador,partituras,cables FROM instrumentos i, piano pi WHERE i.id=pi.instrumento_id and pi.id=?";
           PreparedStatement ps = conn.prepareStatement(query);
             ps.setInt(1,id);
             ResultSet rs = ps.executeQuery();
             
             while(rs.next()){
                 piano= new Piano(rs.getString("nombre"),
                         rs.getDouble("precio"),
                         rs.getString("marca"),
                         rs.getInt("no_teclas"),
                         rs.getString("tamano"),
                          rs.getString("ecualizador"),
                          rs.getString("partituras"),
                          rs.getString("cables"));
                 
             }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar PIANO "+e);
        }
        return piano;
    }

    public void contruirTabla(DefaultTableModel modeloTabla) {
        try {
            Connection conn = Conexion.getConexion();
            String query = "SELECT pi.id, nombre,precio,marca,no_teclas,tamano,ecualizador,partituras,cables from instrumentos i, piano pi WHERE i.id=pi.instrumento_id";
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery();
             ResultSetMetaData rsmd = rs.getMetaData();
             int columnas= rsmd.getColumnCount();
             while(rs.next()){
                 Object[] fila=new Object[columnas];
                 for(int indice = 0; indice < columnas; indice++){
                     fila[indice] = rs.getObject(indice+1);
                 }
                 modeloTabla.addRow(fila);
             }
             
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al contruir tabla "+e);
        }
    }
    
    
    
}
