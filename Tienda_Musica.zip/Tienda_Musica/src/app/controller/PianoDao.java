/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package app.controller;

import app.model.Piano;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author root
 */
public interface PianoDao {
    public abstract void guardarPiano(Piano piano);
    
    public abstract void modificarPiano(Piano piano, int id);
    
    public abstract void eliminarPiano(int id);
    
    public abstract void construirTabla(DefaultTableModel modeloTabla);
    
    public abstract Piano consultarPiano(int id);
    
}
