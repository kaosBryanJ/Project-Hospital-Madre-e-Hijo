/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.controller;


import app.model.Usuario;
import app.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author root
 */
public class UsuarioDaoImp implements UsuarioDao{

    @Override
    public Usuario validarUsuario(String login, String password) {
        Usuario usuario = null;
        try {
            Connection con = Conexion.getConexion();
             String query = "select * from personas p, usuario u where u.persona_id= p.id and login = ? and password = ?";
             PreparedStatement ps = con.prepareStatement(query);
             ps.setString(1,login);
             ps.setString(2,password);
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
               usuario = new Usuario(rs.getString("login"),
                        rs.getString("password"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getInt("edad"),
                        
                        rs.getString("correo"),
                        
                        rs.getString("telefono")
                        
                       
                );
            }
            
        } catch (Exception e) {
            System.out.println("Error al validatr usuario "+e);
        }
        return usuario;
    }
    
}
