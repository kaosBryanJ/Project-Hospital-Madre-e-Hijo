/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package app.controller;


import app.model.Viento;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author root
 */
public interface VientoDao {
    public abstract void guardarViento(Viento viento);
    
    public abstract void modificarViento(Viento viento, int id);
    
    public abstract void eliminarViento(int id);
    
    public abstract void construirTabla(DefaultTableModel modeloTabla);
    
    public abstract Viento consultarViento(int id);
    
}
