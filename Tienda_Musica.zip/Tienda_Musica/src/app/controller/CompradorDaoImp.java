/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.controller;

import app.model.Comprador;

import app.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author root
 */
public class CompradorDaoImp implements CompradorDao{

    @Override
    public void guardarComprador(Comprador comprador) {
        try {
            Connection conn = Conexion.getConexion();
            String query = "INSERT INTO personas(nombre, apellido,edad,correo,telefono) VALUES (?,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, comprador.getNombre());
            ps.setString(2, comprador.getApellido());
            ps.setInt(3, comprador.getEdad());
            ps.setString(4, comprador.getCorreo());
            ps.setString(5,comprador.getTelefono());
            
            ps.executeUpdate();
            
            ResultSet generatedKeys = ps.getGeneratedKeys();
            int persona_id= 0;
            
            if (generatedKeys.next()) {
                persona_id = generatedKeys.getInt(1);
                
                query = "INSERT INTO comprador(no_comprador,direccion,fecha, persona_id) VALUES (?,?,?,?)";
                ps = conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
                ps.setString(1,comprador.getNo_comprador());
                ps.setString(2,comprador.getDireccion());
                ps.setString(3,comprador.getFecha_visita());
                
                ps.setInt(4,persona_id);
                
                ps.executeUpdate();
                
                JOptionPane.showMessageDialog(null, "El comprador se guardo exitosamente");
               
                
            }else{
                JOptionPane.showMessageDialog(null, "El comprador no se guardo exitosamente");
                
            }
        } catch (Exception e) {
             System.out.println("Error de la conexion "+e);
        }
    }

    @Override
    public void modificarComprador(Comprador comprador, int id) {
        try {
            Connection conn = Conexion.getConexion();
            //recuperar ID de instrumento
            String query = "SELECT persona_id,id from comprador where id = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            int persona_id = 0;
            
            while(rs.next()){
                persona_id = rs.getInt("persona_id");
                
            }
            
            query = ("UPDATE personas set nombre=?,apellido=?,edad=?, correo=?, telefono=? WHERE id = ?");
            ps = conn.prepareStatement(query);
            ps.setString(1, comprador.getNombre());
            ps.setString(2, comprador.getApellido());
            ps.setInt(3,comprador.getEdad());
            ps.setString(4, comprador.getCorreo());
            ps.setString(5, comprador.getTelefono());
            ps.setInt(6,persona_id);
            
            ps.executeUpdate();
            
            query = ("update comprador set no_comprador=?,direccion=?,fecha=? where id = ?");
            ps = conn.prepareStatement(query);
            ps.setString(1,comprador.getNo_comprador());
            ps.setString(2, comprador.getDireccion());
            ps.setString(3,comprador.getFecha_visita());
            
            ps.setInt(4,id);
            
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Comprador modificado");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Comprador no modificado "+e);
            
        }
    }

    @Override
    public void eliminarComprador(int id) {
        try {
            Connection conn = Conexion.getConexion();
            
            String query = "SELECT persona_id, id from comprador where id = ?";
             PreparedStatement ps = conn.prepareStatement(query);
             ps.setInt(1,id);
             ResultSet rs = ps.executeQuery();
             int persona_id = 0;
             
             while(rs.next()){
                 persona_id = rs.getInt("persona_id");
                 
             }
             
             //eleiminar el audio
             query = "DELETE FROM comprador where id = ?";
             ps = conn.prepareStatement(query);
             ps.setInt(1, id);
             
             ps.executeUpdate();
             
             //eliminar instrumento
             query = "DELETE FROM personas WHERE id =?";
             ps = conn.prepareStatement(query);
             ps.setInt(1,persona_id);
             
             ps.executeUpdate();
             
             
            JOptionPane.showMessageDialog(null, "El comprador se elimino");
            
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "El comprador no se elimino "+e);
            
        }
    }

    @Override
    public void construirTabla(DefaultTableModel modeloTabla) {
        try {
            Connection conn = Conexion.getConexion();
            String query = "SELECT com.id, nombre,apellido,edad,correo,telefono,no_comprador,direccion,fecha from personas p, comprador com WHERE p.id=com.persona_id";
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery();
             ResultSetMetaData rsmd = rs.getMetaData();
             int columnas= rsmd.getColumnCount();
             while(rs.next()){
                 Object[] fila=new Object[columnas];
                 for(int indice = 0; indice < columnas; indice++){
                     fila[indice] = rs.getObject(indice+1);
                 }
                 modeloTabla.addRow(fila);
             }
             
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al contruir tabla "+e);
        }
    }

    @Override
    public Comprador consultarComprador(int id) {
        Comprador comprador = null;
        try {
           Connection conn = Conexion.getConexion();
           String query = "SELECT com.id, nombre,apellido,edad,correo,telefono,no_comprador,direccion,fecha FROM personas p, comprador com WHERE p.id=com.persona_id and com.id=?";
           PreparedStatement ps = conn.prepareStatement(query);
             ps.setInt(1,id);
             ResultSet rs = ps.executeQuery();
             
             while(rs.next()){
                 comprador = new Comprador(rs.getString("nombre"),
                         rs.getString("apellido"),
                         rs.getInt("edad"),
                         rs.getString("correo"),
                         
                         rs.getString("telefono"),
                         rs.getString("no_comprador"),
                          rs.getString("direccion"),
                          rs.getString("fecha"));
             }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar comprador "+e);
        }
        return comprador;
    }

    public void contruirTabla(DefaultTableModel modeloTabla) {
        try {
            Connection conn = Conexion.getConexion();
            String query = "SELECT com.id, nombre,apellido,edad,correo,telefono,no_comprador,direccion,fecha from personas p, comprador com WHERE p.id=com.persona_id";
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery();
             ResultSetMetaData rsmd = rs.getMetaData();
             int columnas= rsmd.getColumnCount();
             while(rs.next()){
                 Object[] fila=new Object[columnas];
                 for(int indice = 0; indice < columnas; indice++){
                     fila[indice] = rs.getObject(indice+1);
                 }
                 modeloTabla.addRow(fila);
             }
             
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al contruir tabla "+e);
        }
    }
    
}
